import sys, xbmcgui, xbmcplugin
import requests, re
import HTMLParser

_url = sys.argv[0]
_handle = int(sys.argv[1])

koditips = 'https://koditips.com/'
regmti = '-url.*?f\W+(.*?)[\'"].*\n.*?c\W+(.*?)[\'"].*?lt\W+(.*?)[\'"]'

def tipsearch():
	listing = []
	d = xbmcgui.Dialog().input('Enter URL', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		link = koditips + '?s=install+' + d
		link = link.replace(' ','+')
		t3 = requests.get(link)
		t3 = re.compile(regmti, re.I).findall(t3.content)
		for link,icon,title in t3:
			title = HTMLParser.HTMLParser().unescape(title)
			li = xbmcgui.ListItem(label=title, thumbnailImage=koditips+icon)
			is_folder = True
			url = '{0}?action=tips&koditips={1}'.format(_url, link)
			listing.append((url, li, is_folder))	
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.endOfDirectory(_handle)
	