import sys, xbmcgui, xbmcplugin, xbmcaddon
import requests, re
import HTMLParser

_url = sys.argv[0]
_handle = int(sys.argv[1])
addon = xbmcaddon.Addon('plugin.video.kodzi')
icon = addon.getAddonInfo('icon')
s = requests.Session()
s.headers.update({'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:71.0) Gecko/20100101 Firefox/71.0'})

listing = []

def find_monthly_rec():
	link = 'https://www.reddit.com/r/addons4kodi'
	link = s.get(link).text
	reg = '\smoderator.*?f\W+(http.*?)[\'"].*?recommended'
	link = re.compile(reg, re.I).findall(link)[0]
	return link


def sub_cate():
	link = find_monthly_rec()
	getda = s.get(link).text
	comli = re.compile('root"><div class=.*?>(.*?)<(.*?)upvote', re.I).findall(getda)[1:]
	for name,ldata in comli:
		try:
			link = re.compile('blank">(http.*?)<', re.I).findall(ldata)[0]
		except IndexError as error:
			link = 'none'
		name = HTMLParser.HTMLParser().unescape(name)
		li = xbmcgui.ListItem(label=name, thumbnailImage=icon)
		is_folder = True
		url = '{0}?action=listing&category={1}'.format(_url, link)
		listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	xbmcplugin.endOfDirectory(_handle)