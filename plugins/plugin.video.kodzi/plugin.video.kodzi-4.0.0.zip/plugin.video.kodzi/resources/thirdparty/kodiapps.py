import sys, xbmcgui, xbmcplugin
import requests, re

_url = sys.argv[0]
_handle = int(sys.argv[1])

kodiappss = 'https://kodiapps.com/'
kapreg = 'ng-box.*?f\W+(.*?)[\'"].*\n.*?[\'"](.*?)[\'"]'

def main():
	listing = []
	link = kodiappss + 'addons-chart'
	t3 = requests.get(link)
	t3 = re.compile(kapreg, re.I).findall(t3.content)
	for link,icon in t3:
		title = icon.split('/')[-1].split('.')[0].replace('-', ' ')
		li = xbmcgui.ListItem(label=title, thumbnailImage=kodiappss+icon)
		is_folder = False
		link = kodiappss+link
		url = '{0}?action=kodapps&kodiapps={1}'.format(_url, link)
		listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.endOfDirectory(_handle)
	