###############################################################################################
###																							###
###		Don't forget add code to run py.temp before final main rename 	###
###																							###
###############################################################################################
import xbmc, xbmcgui
import os

main_file = xbmc.translatePath('special://home/addons/plugin.video.kodzi/main.py')
adjusted_file = xbmc.translatePath('special://home/addons/plugin.video.kodzi/main.py.temp')

def optmise():
	baseopt()
	if adjusted_file:
		os.rename(adjusted_file, main_file)
		xbmcgui.Dialog().notification('Optimized', 'Kodzi Optimized', xbmcgui.NOTIFICATION_INFO, 5000)
		return remove_optimize()
	else:
		xbmcgui.Dialog().notification('Not Optimized', 'Kodzi is not Optimized', xbmcgui.NOTIFICATION_INFO, 5000)
		return remove_optimize()
	
def remove_optimize():
	#Don'y bother looping just for 2 items, delete it twice for pyo and py
	opt_fileo = xbmc.translatePath('special://home/addons/plugin.video.kodzi/kodzioptmize.pyo')
	opt_file = xbmc.translatePath('special://home/addons/plugin.video.kodzi/kodzioptmize.py')
	try:
		os.remove(opt_fileo)
		os.remove(opt_file)
	except OSError as e:
		print('Error: %s - %s.' % (e.filename, e.strerror))

			  
def baseopt():
	kvers = xbmc.getInfoLabel("System.BuildVersion")
	if kvers < 18:
		return optimiseOLD()
	elif kvers.startswith('18'):
		return optimise18()
	#elif kvers.startswith('19'):
	#	return optimise19()
	else:
		#DO not optimise
		return optimise0
	
def optimise18():
	with open(main_file, "r") as in_file:
		buf = in_file.readlines()

	with open(adjusted_file, "w") as out_file:
		for line in buf:
			if 'kodzioptmize.optmise()' in line:
				line = line.replace(line, '')
			elif 'import kodzioptmize' in line:
				line = line.replace(line, '')
			elif "xbmcgui.ListItem" in line:
				line = line[:-2] + ', offscreen=True)\n'
			out_file.write(line)
			

def optimise19():
	#import urllib.parse as urllib
	return


def optimiseOLD():
	with open(main_file, "r") as in_file:
		buf = in_file.readlines()

	with open(adjusted_file, "w") as out_file:
		for line in buf:
			if "busydialognocancel" in line:
				line = line.replace("busydialognocancel", "busydialog")
			out_file.write(line)
	return

def optimise0():
	return