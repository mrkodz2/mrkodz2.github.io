import sys, xbmcgui, xbmcplugin, xbmcaddon

_url = sys.argv[0]
_handle = int(sys.argv[1])
addon = xbmcaddon.Addon('plugin.video.kodzi')
icon = addon.getAddonInfo('icon')


def main(site):
	listing = []
	k = ('Koditips Search', 'Addons4kodi Recommendations', 'Kodiapps Addons Chart', 'Kodiwpigulce [Polish Content]')
	if site == k[0].split(' ')[0]:
		import koditips
		return koditips.tipsearch()
	elif site == k[1].split(' ')[0]:
		import addons4kodi
		return addons4kodi.sub_cate()
	elif site == k[2].split(' ')[0]:
		import kodiapps
		return kodiapps.main()
	elif site == k[3].split(' ')[0]:
		import main
		return main.kodiwpigulce()
	else:
		for x in k:
			li = xbmcgui.ListItem(label=x, thumbnailImage=icon)
			is_folder = True
			site = x.split(' ')[0]
			url = '{0}?action=3rdparty&site={1}'.format(_url, site)
			listing.append((url, li, is_folder))
		xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
		xbmcplugin.endOfDirectory(_handle)
		

